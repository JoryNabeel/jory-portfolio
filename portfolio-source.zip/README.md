# Jory Sulimani — Portfolio

Professional portfolio built with React and Vite.

## Development

```sh
npm ci
npm run dev
```

## Publishing

Run `npm run build -- --outDir docs` and commit the updated `docs/` directory. GitHub Pages publishes `main` → `/docs`.
