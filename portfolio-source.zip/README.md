# Jory Sulemani - Portfolio

React and Vite source. Install with npm ci and preview with npm run dev.
Build with npm run build. Publish the dist contents to the GitHub Pages repository root, preserving the assets directory.
The live repository currently contains a compiled release at its root and this source archive.
