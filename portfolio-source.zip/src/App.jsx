import React, { useState, useEffect, useRef } from "react";

/* =========================================================
   ✏️  EDIT HERE ONLY — everything below is safe to change
       without touching the rest of the file.
   ========================================================= */

// Headshot: replace with a hosted image URL, e.g. "/images/jory.jpg".
// Leave as null to keep the "JS" monogram placeholder in the hero.
const PROFILE_PHOTO_URL = null;

// Inbox the contact form should reach. Required for "Send message" to work.
const CONTACT_EMAIL = "jory.sulimani25@gmail.com";

// One-page summary PDF (replaces a formal CV). Point this at the hosted file
// once the site is deployed — for now it resolves relative to the site root.
const SUMMARY_FILE_URL = `${import.meta.env.BASE_URL}jory-sulemani-summary.pdf`;

// Optional external profiles. Set to null to hide a link entirely
// (never invent a URL here — only add real, working links).
const SOCIAL_LINKS = {
  github: "https://jorynabeel.github.io/Coffee-Statistics",
  linkedin: "https://www.linkedin.com/in/jory-sulimani-0981243a4",
};

/* =========================================================
   End of editable section.
   ========================================================= */

/* =========================================================
   Design tokens — shared across the whole site
   ========================================================= */
const CONSTANT_TOKENS = {
  accent: "#0E7C86",
  accentDark: "#0A5C64",
  accentTint: "#E6F3F3",
  good: "#0E7C86",
  bad: "#98A2B3",
  warnBg: "#FDF2E3",
  warnFg: "#8A5A0C",
};

const LIGHT_TOKENS = {
  bg: "#FFFFFF",
  bgAlt: "#F7F9FA",
  card: "#FFFFFF",
  ink: "#101828",
  sub: "#475467",
  faint: "#98A2B3",
  border: "#E4E7EC",
  navBg: "rgba(255,255,255,0.9)",
};

const DARK_TOKENS = {
  bg: "#0B0F14",
  bgAlt: "#11161C",
  card: "#151B22",
  ink: "#F2F4F7",
  sub: "#9AA4B2",
  faint: "#6B7480",
  border: "#232B33",
  navBg: "rgba(11,15,20,0.88)",
};

// `c` is intentionally a mutable module-level object: toggling the theme
// mutates its fields in place, and the next React render picks up the
// updated values wherever `c.xxx` is read.
let c = { ...LIGHT_TOKENS, ...CONSTANT_TOKENS };
function applyTheme(mode) {
  Object.assign(c, mode === "dark" ? DARK_TOKENS : LIGHT_TOKENS);
}

/* =========================================================
   Routes — each entry is now a real, bookmarkable page (#/path)
   ========================================================= */
const ROUTES = [
  { label: "Research", path: "/research" },
  { label: "Approach", path: "/approach" },
  { label: "Healthcare AI", path: "/healthcare-ai" },
  { label: "Experience", path: "/experience" },
  { label: "Summary", path: "/summary" },
  { label: "Contact", path: "/contact" },
];

/* =========================================================
   Hero / snapshot content
   ========================================================= */
const snapshot = [
  {
    label: "Medical statistics",
    detail: "Survival analysis, regression, biomarker analysis",
    icon: <path d="M4 20V10M11 20V4M18 20v-7" stroke={c.accent} strokeWidth="1.8" strokeLinecap="round" />,
  },
  {
    label: "Clinical research",
    detail: "Patient-level data, multi-cohort analysis, scientific interpretation",
    icon: (
      <>
        <rect x="5" y="3.5" width="14" height="17" rx="2" stroke={c.accent} strokeWidth="1.8" />
        <path d="M9 8h6M9 12h6M9 16h3.5" stroke={c.accent} strokeWidth="1.8" strokeLinecap="round" />
      </>
    ),
  },
  {
    label: "Data & programming",
    detail: "R, data preparation, SQL fundamentals",
    icon: (
      <path d="M8 7 3.5 12 8 17M16 7l4.5 5-4.5 5M13.5 5.5l-3 13" stroke={c.accent} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    ),
  },
  {
    label: "Healthcare AI",
    detail: "Statistical foundations for biomedical AI",
    note: "Research direction",
    icon: (
      <>
        <circle cx="12" cy="12" r="3.2" stroke={c.accent} strokeWidth="1.8" />
        <path d="M12 3.5v3M12 17.5v3M20.5 12h-3M6.5 12h-3M17.7 6.3l-2 2M8.3 15.7l-2 2M17.7 17.7l-2-2M8.3 8.3l-2-2" stroke={c.accent} strokeWidth="1.6" strokeLinecap="round" />
      </>
    ),
  },
];

// Teaser cards on the homepage linking out to each real page
const pageTeasers = [
  { path: "/research", title: "Research", body: "A collaborative study of 3,223 patients — the research question, methods, and my analytical contribution." },
  { path: "/approach", title: "Approach", body: "How I think about healthcare data, step by step, from defining the question to communicating uncertainty." },
  { path: "/healthcare-ai", title: "Healthcare AI", body: "Building from statistical foundations toward healthcare AI — current research directions." },
  { path: "/experience", title: "Experience", body: "Professional experience, projects, skills, education, and certifications." },
  { path: "/summary", title: "Summary", body: "Download a concise one-page summary of the work above." },
  { path: "/contact", title: "Contact", body: "Contact me about research collaboration, statistics, healthcare analytics, and data analysis opportunities." },
];

/* =========================================================
   Research page content
   ========================================================= */
const tabs = [
  { id: "question", label: "Clinical question" },
  { id: "data", label: "Data" },
  { id: "methods", label: "Methods" },
  { id: "results", label: "My contribution" },
  { id: "integrity", label: "What it shows" },
  { id: "status", label: "Status" },
];

const methods = [
  {
    "name": "Data preparation",
    "what": "Cleaning, combining, and harmonizing de-identified clinical data across eight cohorts.",
    "why": "Creates a consistent foundation for comparing variables and survival outcomes.",
    "not": "Combining datasets does not eliminate differences between their populations or collection methods."
  },
  {
    "name": "Exploratory analysis",
    "what": "Summarizing variables, inspecting distributions, and checking data quality in R.",
    "why": "Identifies missingness, inconsistencies, and patterns that shape subsequent analysis.",
    "not": "Descriptive patterns alone do not establish a causal relationship."
  },
  {
    "name": "Kaplan–Meier",
    "what": "Estimating survival over time and visualizing differences between ALP groups.",
    "why": "Makes survival patterns interpretable while accounting for right-censored observations.",
    "not": "Group differences require further analysis and clinical interpretation."
  },
  {
    "name": "Log-rank test",
    "what": "Comparing survival distributions between groups.",
    "why": "Provides a formal test alongside the survival curves.",
    "not": "A test result does not quantify an effect size or establish causality."
  },
  {
    "name": "Cox regression",
    "what": "Modeling the association between ALP and survival with covariate adjustment.",
    "why": "Examines associations while accounting for available patient characteristics.",
    "not": "Adjustment cannot remove all confounding or establish clinical validity."
  },
  {
    "name": "Subgroup & sensitivity analysis",
    "what": "Examining findings across subsets and alternative analytical choices.",
    "why": "Assesses how results depend on the population and analysis specification.",
    "not": "Robustness within the available data does not replace external validation."
  }
];

const integrityData = {
  "supported": [
    "Analysis of de-identified clinical data across eight cohorts",
    "Kaplan–Meier estimation and log-rank testing",
    "Cox regression and sensitivity analysis",
    "Collaborative research reporting"
  ],
  "notEstablished": [
    "Causality",
    "Prospective clinical validation",
    "A standalone clinical prediction tool",
    "Universal treatment or diagnostic thresholds"
  ]
};

const limitations = [
  {
    "title": "Observational data",
    "body": "The analysis concerns associations in existing clinical data; it does not establish causality."
  },
  {
    "title": "Differences between cohorts",
    "body": "Population characteristics, variable availability, and data collection differ across sources and must be considered when interpreting findings."
  },
  {
    "title": "Clinical applicability",
    "body": "Research findings require further evaluation before use in individual patient decisions."
  }
];

const statusSteps = [
  {
    "title": "Graduation research",
    "state": "Completed",
    "body": "Collaborative ALP survival study covering 3,223 patients across eight cohorts, with a research report and poster."
  },
  {
    "title": "Manuscript development",
    "state": "Current",
    "body": "Contributing to a manuscript in preparation for journal submission."
  },
  {
    "title": "Further research",
    "state": "Research direction",
    "body": "Interested in extending survival analysis and evaluating predictive methods using broader clinical data."
  }
];

/* =========================================================
   Approach + Healthcare AI content
   ========================================================= */
const steps = [
  { title: "Define the question", body: "Start from the clinical or research question, not the dataset. What decision or understanding is this analysis meant to support?" },
  { title: "Understand the data", body: "Learn where the data came from, how it was collected, what each variable actually measures, and what population it represents." },
  { title: "Check data quality", body: "Look for missing values, inconsistent coding, duplicate records, and implausible entries before any modeling begins." },
  { title: "Choose the right method", body: "Let the question and the structure of the data determine the method — survival analysis, regression, or something else — rather than defaulting to whichever tool is most familiar." },
  { title: "Test assumptions", body: "Every statistical method rests on assumptions. Check them explicitly instead of trusting a model because it ran without errors." },
  { title: "Validate the result", body: "Use diagnostics, sensitivity analysis, and cross-checks to see whether a finding holds up under reasonable variations in the approach." },
  { title: "Interpret in context", body: "A statistical result means something different in different clinical settings. Read findings alongside the biology and the population they came from." },
  { title: "Communicate uncertainty", body: "Report confidence intervals, heterogeneity, and limitations as part of the finding, not as a footnote to it." },
];

const bridge = ["Statistics", "Biomedical data", "Statistical modeling", "Machine learning", "Healthcare AI"];

const aiAreas = [
  "Survival modeling",
  "Clinical prediction",
  "Biomedical machine learning",
  "Statistical validation of AI systems",
  "Healthcare data analysis",
];

/* =========================================================
   Experience / Projects / Skills / Education / Certifications
   ========================================================= */
const experience = [
  {
    "role": "Junior Statistician",
    "org": "Smart Business Systems (SBS)",
    "period": "August 2025 – Present",
    "bullets": [
      "Independently clean, validate, and prepare real clinical datasets in R for research analysis.",
      "Apply survival analysis, regression, and hypothesis testing to healthcare research questions.",
      "Combine data across cohorts and translate statistical results into tables, visualizations, and research reports.",
      "Contribute to interpretation, scientific reporting, and manuscript preparation within research teams.",
      "Conducted on-site observation of HLA laboratory workflows and authored a structured report documenting observations."
    ]
  },
  {
    "role": "E-Learning & Distance Education Trainee",
    "org": "Deanship of E-Learning and Distance Education, King Abdulaziz University",
    "period": "August 2025 – January 2026",
    "bullets": [
      "Independently developed and published Coffee Statistics, an educational website translating statistical concepts into accessible content.",
      "Worked from the Deanship’s requirements through content preparation, development, and publishing on GitHub Pages.",
      "Prepared educational presentations, a poster, and a statistics booklet for non-specialist audiences.",
      "Used AI-assisted development tools to support implementation and technical problem-solving."
    ],
    "link": {
      "label": "Explore Coffee Statistics",
      "href": "https://jorynabeel.github.io/Coffee-Statistics"
    }
  }
];

const secondaryProject = {
  "title": "Time series analysis — sunspot activity",
  "meta": "Time Series Analysis · King Abdulaziz University",
  "points": [
    "Analyzed monthly sunspot observations spanning 1749–2021.",
    "Examined stationarity and differencing as part of time-series preparation.",
    "Compared ARIMA specifications using AIC; selected ARIMA(2,1,2).",
    "Developed practical experience in statistical forecasting and model interpretation."
  ]
};

const skillGroups = [
  {
    "title": "Statistical analysis · applied",
    "items": [
      "Survival analysis",
      "Kaplan–Meier",
      "Log-rank tests",
      "Cox regression",
      "Regression analysis",
      "Hypothesis testing",
      "Exploratory analysis",
      "Subgroup & sensitivity analysis"
    ]
  },
  {
    "title": "Research & healthcare workflows",
    "items": [
      "Clinical data preparation",
      "Data quality checks",
      "Multi-cohort analysis",
      "Statistical interpretation",
      "Research reports & posters",
      "Manuscript contribution",
      "Workflow documentation"
    ]
  },
  {
    "title": "Programming & analytics",
    "items": [
      "R — strong working proficiency",
      "SQL — foundational queries & joins",
      "Microsoft Excel",
      "Power BI — basic exposure",
      "GitHub Pages"
    ]
  },
  {
    "title": "Academic methods & further development",
    "items": [
      "Time series & ARIMA",
      "Classification & clustering",
      "Random Forest — coursework",
      "Bayesian networks — coursework",
      "AI-assisted technical workflows",
      "Healthcare AI — career direction"
    ]
  }
];

const certifications = [
  {
    "name": "Certified Business Professional – Project Management (CBP-PM)",
    "org": "Professional certification",
    "meta": "Exam passed · Certificate awarded"
  },
  {
    "name": "Introduction to Modern Artificial Intelligence",
    "org": "Doroob",
    "meta": "October 2025 · Introductory training"
  },
  {
    "name": "Understanding Your Digital World with Power BI",
    "org": "Digital Giving Initiative",
    "meta": "September 2025 · Webinar"
  }
];

const coursework = ["Data Mining", "Big Data", "Machine Learning", "Time Series Analysis", "Regression Analysis", "Statistical Quality Control"];

/* =========================================================
   Small shared components
   ========================================================= */
function StatePill({ state }) {
  const styles = {
    Completed: { bg: c.accentTint, fg: c.accentDark },
    Current: { bg: c.warnBg, fg: c.warnFg },
    "Research direction": { bg: c.bgAlt, fg: c.sub },
  };
  const s = styles[state] || styles["Research direction"];
  return (
    <span style={{ fontSize: 11.5, fontWeight: 600, color: s.fg, background: s.bg, padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" }}>
      {state}
    </span>
  );
}

function ReservedTag() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 12.5, fontWeight: 600, color: c.warnFg, background: c.warnBg, padding: "6px 12px", borderRadius: 999 }}>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="5" y="10" width="14" height="10" rx="2" stroke={c.warnFg} strokeWidth="1.8" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" stroke={c.warnFg} strokeWidth="1.8" />
      </svg>
      Collaborative graduation research · Manuscript in preparation
    </span>
  );
}

function Stat({ value, label }) {
  return (
    <div style={{ background: c.bgAlt, borderRadius: 10, padding: "16px 16px" }}>
      <p style={{ fontSize: 24, fontWeight: 800, margin: 0 }}>{value}</p>
      <p style={{ fontSize: 12.5, color: c.sub, margin: "4px 0 0" }}>{label}</p>
    </div>
  );
}

function MethodRow({ label, text, last }) {
  return (
    <div style={{ marginBottom: last ? 0 : 16 }}>
      <p style={{ fontSize: 12, fontWeight: 700, color: c.faint, margin: "0 0 4px", textTransform: "uppercase", letterSpacing: "0.03em" }}>{label}</p>
      <p style={{ fontSize: 14.5, color: c.sub, lineHeight: 1.7, margin: 0, maxWidth: 600 }}>{text}</p>
    </div>
  );
}

function Check() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true" style={{ flexShrink: 0, marginTop: 2 }}>
      <circle cx="8" cy="8" r="7.25" stroke={c.good} strokeWidth="1.3" />
      <path d="M5 8.2 7.1 10.3 11 6" stroke={c.good} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Cross() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true" style={{ flexShrink: 0, marginTop: 2 }}>
      <circle cx="8" cy="8" r="7.25" stroke={c.bad} strokeWidth="1.3" />
      <path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke={c.bad} strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function useCountUp(target, active, duration = 900) {
  const [val, setVal] = useState(0);
  const startRef = useRef(null);
  useEffect(() => {
    if (!active) return;
    const reduce = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { setVal(target); return; }
    let raf;
    const step = (ts) => {
      if (startRef.current === null) startRef.current = ts;
      const p = Math.min((ts - startRef.current) / duration, 1);
      setVal(target * p);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [active, target, duration]);
  return Math.round(val);
}

/* =========================================================
   Tiny hash router — no external dependency, works in any
   sandbox and on any static host (GitHub Pages, Vercel, etc.)
   without server rewrite rules.
   ========================================================= */
function useHashRoute() {
  const getPath = () => {
    const h = typeof window !== "undefined" ? window.location.hash : "";
    const clean = (h || "#/").replace(/^#/, "");
    return clean.startsWith("/") ? clean : "/" + clean;
  };
  const [path, setPath] = useState(getPath());

  // Best-effort: reflect the URL when it's *externally* changed (typed,
  // bookmarked, or the browser's own back/forward button on a real deployed
  // site). This is a bonus, not the primary mechanism — see `navigate` below.
  useEffect(() => {
    const onChange = () => setPath(getPath());
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  // Primary mechanism: navigate() updates React state directly, so page
  // switching always works even in sandboxed preview environments where a
  // plain <a href="#..."> click doesn't reliably update window.location.hash.
  // It still *tries* to update the visible URL too, so on a real deployed
  // site the address bar, bookmarks, and browser back/forward all work.
  const navigate = (newPath) => {
    setPath(newPath);
    try {
      window.history.pushState(null, "", `#${newPath}`);
    } catch (err) {
      try { window.location.hash = newPath; } catch (err2) { /* ignore */ }
    }
  };

  return [path, navigate];
}

/* =========================================================
   Page: Home
   ========================================================= */
function HomePage({ navigate }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 30);
    return () => clearTimeout(t);
  }, []);
  const reduceMotion = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  return (
    <>
      <section style={{ maxWidth: 1160, margin: "0 auto", padding: "72px 24px 60px" }}>
        <div className="jn2-hero-grid" style={{ display: "grid", gridTemplateColumns: "1.05fr 0.95fr", gap: 56, alignItems: "center" }}>
          <div className={`jn2-fade ${mounted || reduceMotion ? "jn2-in" : ""}`}>
            {PROFILE_PHOTO_URL ? (
              <img src={PROFILE_PHOTO_URL} alt="Jory Sulemani" style={{ width: 64, height: 64, borderRadius: "50%", objectFit: "cover", marginBottom: 20, border: `1px solid ${c.border}` }} />
            ) : (
              <div aria-hidden="true" style={{ width: 64, height: 64, borderRadius: "50%", background: c.accentTint, color: c.accentDark, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 700, marginBottom: 20, border: `1px solid ${c.accent}33` }}>JS</div>
            )}

            <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 13, fontWeight: 600, color: c.accentDark, background: c.accentTint, border: `1px solid ${c.accent}33`, padding: "6px 12px", borderRadius: 999, marginBottom: 22 }}>
              <span aria-hidden="true" style={{ width: 6, height: 6, borderRadius: "50%", background: c.accent }} />
              Junior Statistician
            </span>

            <h1 className="jn2-hero-title" style={{ fontSize: 54, lineHeight: 1.08, fontWeight: 800, letterSpacing: "-0.02em", margin: "0 0 20px" }}>
              Jory Sulemani
            </h1>

            <p style={{ fontSize: 19, fontWeight: 500, color: c.ink, margin: "0 0 16px" }}>
              Medical statistics · clinical research · data analysis
            </p>

            <p style={{ fontSize: 16, color: c.sub, lineHeight: 1.7, margin: "0 0 34px", maxWidth: 480 }}>
              I turn real clinical data into clear statistical findings using R. My work spans
              data preparation, survival analysis, research reporting, and healthcare
              workflow documentation. I am building on this foundation toward healthcare AI.
            </p>

            <p style={{ fontSize: 13, color: c.sub, lineHeight: 1.6, margin: "0 0 22px" }}>Based in Jeddah · Open to relocation within Saudi Arabia<br />Interested in statistics, healthcare analytics, clinical research, and data analysis opportunities.</p>
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <a href="#/research" onClick={(e) => { e.preventDefault(); navigate("/research"); }} className="jn2-btn-primary">Explore the research</a>
              <a href="#/summary" onClick={(e) => { e.preventDefault(); navigate("/summary"); }} className="jn2-btn-secondary">Download summary</a>
            </div>
          </div>

          <div className={`jn2-fade jn2-panel ${mounted || reduceMotion ? "jn2-in" : ""}`} style={{ transitionDelay: "0.12s" }}>
            <div className="jn2-card" style={{ padding: 26 }}>
              <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "0 0 8px", letterSpacing: "0.02em" }}>Featured research</p>
              <h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 4px" }}>ALP and survival: a multicohort study</h2>
              <p style={{ fontSize: 13.5, color: c.sub, margin: "0 0 22px" }}>Statistical study of ALP and survival outcomes</p>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 22 }}>
                <div style={{ background: c.bgAlt, borderRadius: 10, padding: "12px 14px" }}>
                  <p style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>3,223</p>
                  <p style={{ fontSize: 12, color: c.sub, margin: "2px 0 0" }}>Patients</p>
                </div>
                <div style={{ background: c.bgAlt, borderRadius: 10, padding: "12px 14px" }}>
                  <p style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>8</p>
                  <p style={{ fontSize: 12, color: c.sub, margin: "2px 0 0" }}>Clinical cohorts</p>
                </div>
              </div>

              <div style={{ borderTop: `1px solid ${c.border}`, paddingTop: 18 }}>
                <p style={{ fontSize: 12, color: c.sub, margin: "0 0 8px" }}>My contribution</p>
                <p style={{ fontSize: 14.5, color: c.ink, lineHeight: 1.65, margin: "0 0 14px" }}>
                  Prepared and analyzed clinical data in R and contributed to interpretation and research reporting within a collaborative graduation project.
                </p>
                <span style={{ display: "inline-block", fontSize: 11.5, fontWeight: 600, color: c.accentDark, background: c.accentTint, padding: "4px 10px", borderRadius: 999 }}>
                  Collaborative graduation research
                </span>
              </div>
              <p style={{ fontSize: 11.5, color: c.faint, margin: "12px 0 0", lineHeight: 1.5 }}>
                Kaplan–Meier · Log-rank · Cox regression · R
              </p>
            </div>
          </div>
        </div>
      </section>

      <section aria-label="Professional snapshot" style={{ background: c.bgAlt, borderTop: `1px solid ${c.border}` }}>
        <div className={`jn2-fade jn2-snap-grid ${mounted || reduceMotion ? "jn2-in" : ""}`} style={{ maxWidth: 1160, margin: "0 auto", padding: "48px 24px", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 18, transitionDelay: "0.2s" }}>
          {snapshot.map((item) => (
            <div key={item.label} className="jn2-card" style={{ padding: 22 }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true" style={{ marginBottom: 14 }}>{item.icon}</svg>
              <h3 style={{ fontSize: 15, fontWeight: 600, margin: "0 0 8px" }}>{item.label}</h3>
              <p style={{ fontSize: 13.5, color: c.sub, lineHeight: 1.6, margin: 0 }}>{item.detail}</p>
              {item.note && <p style={{ fontSize: 11.5, color: c.accentDark, fontWeight: 600, margin: "12px 0 0" }}>{item.note}</p>}
            </div>
          ))}
        </div>
      </section>

      <section style={{ maxWidth: 1160, margin: "0 auto", padding: "72px 24px 100px" }}>
        <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Explore</p>
        <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 32px" }}>Each page in one place</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 16 }}>
          {pageTeasers.map((p) => (
            <a
              key={p.path}
              href={`#${p.path}`}
              onClick={(e) => { e.preventDefault(); navigate(p.path); }}
              className="jn2-card teaser-card"
              style={{ padding: 22, textDecoration: "none", color: c.ink, display: "block" }}
            >
              <h3 style={{ fontSize: 15.5, fontWeight: 700, margin: "0 0 8px" }}>{p.title}</h3>
              <p style={{ fontSize: 13.5, color: c.sub, lineHeight: 1.6, margin: "0 0 14px" }}>{p.body}</p>
              <span style={{ fontSize: 13, fontWeight: 600, color: c.accentDark }}>View page →</span>
            </a>
          ))}
        </div>
      </section>
    </>
  );
}

/* =========================================================
   Page: Research
   ========================================================= */
function ResearchPage({ subPath, navigate }) {
  const initial = tabs.some((t) => t.id === subPath) ? subPath : "question";
  const [activeTab, setActiveTabState] = useState(initial);
  const [activeMethod, setActiveMethod] = useState(0);
  const [openLimitation, setOpenLimitation] = useState(null);
  const [dataVisible, setDataVisible] = useState(initial === "data");

  const setActiveTab = (id) => {
    setActiveTabState(id);
    navigate(`/research/${id}`);
    if (id === "data") setDataVisible(true);
  };

  const patients = useCountUp(3223, dataVisible);
  const cohorts = useCountUp(8, dataVisible);

  return (
    <section style={{ maxWidth: 1160, margin: "0 auto", padding: "56px 24px 40px" }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 13, fontWeight: 600, color: c.accentDark, background: c.accentTint, border: `1px solid ${c.accent}33`, padding: "6px 12px", borderRadius: 999, marginBottom: 18 }}>
        <span aria-hidden="true" style={{ width: 6, height: 6, borderRadius: "50%", background: c.accent }} />
        Featured research
      </span>

      <h2 style={{ fontSize: 36, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 12px" }}>
        ALP and survival: a multicohort statistical study
      </h2>
      <p style={{ fontSize: 16.5, color: c.sub, maxWidth: 640, lineHeight: 1.6, margin: "0 0 40px" }}>
        A collaborative graduation research project examining alkaline phosphatase (ALP)
        and survival outcomes across eight clinical cohorts. My contribution focused on
        data preparation, statistical analysis in R, interpretation, and research reporting.
      </p>

      <div role="tablist" aria-label="Research sections" style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4, marginBottom: 32 }}>
        {tabs.map((t) => (
          <button key={t.id} role="tab" aria-selected={activeTab === t.id} className={`rs-tab ${activeTab === t.id ? "on" : ""}`} onClick={() => setActiveTab(t.id)}>{t.label}</button>
        ))}
      </div>

      {activeTab === "question" && (
        <div className="rs-panel rs-card" style={{ padding: 32 }}>
          <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "0 0 10px" }}>The question</p>
          <h3 style={{ fontSize: 22, fontWeight: 700, lineHeight: 1.4, margin: "0 0 20px", maxWidth: 640 }}>
            Can routinely measured serum alkaline phosphatase provide consistent prognostic information across heterogeneous clinical populations?
          </h3>
          <p style={{ fontSize: 15, color: c.sub, lineHeight: 1.75, maxWidth: 640, margin: 0 }}>
            ALP is a low-cost enzyme measured as part of routine hepatic and metabolic panels,
            and this project explores its relationship with survival across different clinical
            populations. The focus is on the{" "}
            <strong style={{ fontWeight: 600 }}>association</strong> between serum ALP levels and
            survival outcomes across the included clinical populations, accounting for differences
            between cohorts and the limitations of the available data.
          </p>
        </div>
      )}

      {activeTab === "data" && (
        <div className="rs-panel rs-card" style={{ padding: 32 }}>
          <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "0 0 20px" }}>The dataset</p>
          <div className="rs-stat-row" style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28 }}>
            <Stat value={Math.round(patients).toLocaleString()} label="Patient records" />
            <Stat value={Math.round(cohorts)} label="Clinical cohorts" />
            <Stat value="R" label="Primary analysis tool" />
            <Stat value="Team" label="Collaborative research" />
          </div>
          <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 12 }}>
            {[
              "Real, de-identified clinical data drawn from multiple sources",
              "A multi-cohort study population of 3,223 patients across eight cohorts",
              "Preparation and harmonization of variables for survival analysis",
              "Analysis and reporting carried out as part of a collaborative graduation project",
            ].map((line) => (
              <li key={line} style={{ display: "flex", gap: 10, fontSize: 14.5, color: c.sub, lineHeight: 1.6 }}>
                <Check /><span>{line}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {activeTab === "methods" && (
        <div className="rs-panel">
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 20 }}>
            {methods.map((m, i) => (
              <button key={m.name} className={`rs-method ${activeMethod === i ? "on" : ""}`} onClick={() => setActiveMethod(i)}>{m.name}</button>
            ))}
          </div>
          <div className="rs-card" style={{ padding: 28 }}>
            <h4 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 18px" }}>{methods[activeMethod].name}</h4>
            <MethodRow label="What it does" text={methods[activeMethod].what} />
            <MethodRow label="Why it was used" text={methods[activeMethod].why} />
            <MethodRow label="What it does not prove" text={methods[activeMethod].not} last />
          </div>
        </div>
      )}

      {activeTab === "results" && (
        <div className="rs-panel">
          <div className="rs-two-col" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
            <div className="rs-card" style={{ padding: 28 }}>
              <p style={{ fontSize: 12.5, fontWeight: 600, color: c.accentDark, margin: "0 0 10px" }}>My contribution</p>
              <h3 style={{ fontSize: 19, margin: "0 0 14px" }}>From clinical records to statistical findings</h3>
              <p style={{ fontSize: 14.5, color: c.sub, lineHeight: 1.75, margin: 0 }}>I prepared and combined cohort data, performed survival analyses in R, and contributed to interpretation and research reporting. The research was a team project; these are my analytical contributions.</p>
            </div>
            <div className="rs-card" style={{ padding: 28 }}>
              <p style={{ fontSize: 12.5, fontWeight: 600, color: c.accentDark, margin: "0 0 10px" }}>Research outputs</p>
              <h3 style={{ fontSize: 19, margin: "0 0 14px" }}>Report, poster, and manuscript contribution</h3>
              <p style={{ fontSize: 14.5, color: c.sub, lineHeight: 1.75, margin: 0 }}>The project produced a graduation research report and poster. A manuscript is in preparation. This portfolio describes the analytical work; detailed numerical findings are not reproduced here.</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === "integrity" && (
        <div className="rs-panel">
          <div className="rs-two-col" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <div className="rs-card" style={{ padding: 28 }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: c.accentDark, margin: "0 0 16px" }}>Supported by the study</p>
              <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 12 }}>
                {integrityData.supported.map((item) => (
                  <li key={item} style={{ display: "flex", gap: 10, fontSize: 14, color: c.sub }}><Check /> <span>{item}</span></li>
                ))}
              </ul>
            </div>
            <div className="rs-card" style={{ padding: 28 }}>
              <p style={{ fontSize: 13, fontWeight: 700, color: c.sub, margin: "0 0 16px" }}>Not established by the study</p>
              <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 12 }}>
                {integrityData.notEstablished.map((item) => (
                  <li key={item} style={{ display: "flex", gap: 10, fontSize: 14, color: c.sub }}><Cross /> <span>{item}</span></li>
                ))}
              </ul>
            </div>
          </div>

          <div className="rs-card" style={{ padding: "8px 28px", marginTop: 20 }}>
            <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "18px 0 0" }}>Limitations</p>
            {limitations.map((l, i) => (
              <div key={l.title}>
                <button className="rs-limrow" aria-expanded={openLimitation === i} onClick={() => setOpenLimitation(openLimitation === i ? null : i)}>
                  <span style={{ fontSize: 14.5, fontWeight: 600, color: c.ink }}>{l.title}</span>
                  <span aria-hidden="true" style={{ fontSize: 18, color: c.faint, transform: openLimitation === i ? "rotate(45deg)" : "none", transition: "transform 0.15s ease" }}>+</span>
                </button>
                {openLimitation === i && <p style={{ fontSize: 14, color: c.sub, lineHeight: 1.7, margin: "0 0 16px", maxWidth: 620 }}>{l.body}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "status" && (
        <div className="rs-panel rs-card" style={{ padding: 32 }}>
          {statusSteps.map((s, i) => (
            <div key={s.title} style={{ display: "flex", gap: 20, paddingTop: i === 0 ? 0 : 22, marginTop: i === 0 ? 0 : 22, borderTop: i === 0 ? "none" : `1px solid ${c.border}` }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                <span aria-hidden="true" style={{ width: 10, height: 10, borderRadius: "50%", background: s.state === "Completed" ? c.accent : c.card, border: `2px solid ${s.state === "Completed" ? c.accent : c.border}`, marginTop: 4 }} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                  <h4 style={{ fontSize: 15.5, fontWeight: 700, margin: 0 }}>{s.title}</h4>
                  <StatePill state={s.state} />
                </div>
                <p style={{ fontSize: 14, color: c.sub, lineHeight: 1.65, margin: 0, maxWidth: 560 }}>{s.body}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="rs-card" style={{ padding: 28, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16, marginTop: 40 }}>
        <div>
          <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "0 0 6px" }}>Publications & presentations</p>
          <p style={{ fontSize: 14.5, color: c.sub, margin: 0, maxWidth: 480 }}>
            A manuscript based on this research is in preparation. This section will be
            updated as the work moves through peer review and presentation.
          </p>
        </div>
        <span style={{ fontSize: 12, fontWeight: 600, color: c.warnFg, background: c.warnBg, padding: "6px 12px", borderRadius: 999, whiteSpace: "nowrap" }}>
          Updates coming soon
        </span>
      </div>
    </section>
  );
}

/* =========================================================
   Page: Approach
   ========================================================= */
function ApproachPage() {
  const [activeStep, setActiveStep] = useState(0);
  return (
    <section style={{ maxWidth: 1160, margin: "0 auto", padding: "56px 24px 100px" }}>
      <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Approach</p>
      <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 14px" }}>How I think about healthcare data</h2>
      <p style={{ fontSize: 16, color: c.sub, lineHeight: 1.7, maxWidth: 640, margin: "0 0 40px" }}>
        Healthcare data should not be treated as a conventional machine-learning problem
        by default. The analytical method should follow the clinical question, the
        structure of the data, and the assumptions that can reasonably be supported.
      </p>

      <div style={{ display: "grid", gap: 10, maxWidth: 700 }}>
        {steps.map((s, i) => (
          <div key={s.title} className="ap-acc-item">
            <button
              className={`ap-acc-head ${activeStep === i ? "on" : ""}`}
              onClick={() => setActiveStep(activeStep === i ? -1 : i)}
              aria-expanded={activeStep === i}
              aria-controls={`approach-panel-${i}`}
              id={`approach-tab-${i}`}
            >
              <span className="ap-num" aria-hidden="true">{i + 1}</span>
              <span style={{ fontSize: 14.5, fontWeight: 600, color: c.ink, flex: 1 }}>{s.title}</span>
              <span aria-hidden="true" style={{ fontSize: 18, color: c.faint, transform: activeStep === i ? "rotate(45deg)" : "none", transition: "transform 0.15s ease" }}>+</span>
            </button>
            {activeStep === i && (
              <div className="ap-acc-body" id={`approach-panel-${i}`} role="region" aria-labelledby={`approach-tab-${i}`}>
                <p style={{ fontSize: 14.5, color: c.sub, lineHeight: 1.75, margin: 0, maxWidth: 640 }}>{s.body}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================================
   Page: Healthcare AI
   ========================================================= */
function HealthcareAIPage() {
  return (
    <section style={{ maxWidth: 1160, margin: "0 auto", padding: "56px 24px 100px" }}>
      <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Healthcare AI</p>
      <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 14px" }}>Building from statistical foundations toward healthcare AI</h2>
      <p style={{ fontSize: 16, color: c.sub, lineHeight: 1.75, maxWidth: 640, margin: "0 0 44px" }}>
        My professional direction combines medical statistics, biomedical data analysis, and
        artificial intelligence. I'm particularly interested in how statistical rigor can
        improve the development, evaluation, and interpretation of AI systems in healthcare.
      </p>

      <div className="ap-bridge" style={{ marginBottom: 48 }}>
        {bridge.map((n, i) => (
          <React.Fragment key={n}>
            <span className={`ap-node ${i === bridge.length - 1 ? "last" : ""}`}>{n}</span>
            {i < bridge.length - 1 && (
              <svg width="18" height="12" viewBox="0 0 18 12" fill="none" aria-hidden="true">
                <path d="M0 6h16M11 1l5 5-5 5" stroke={c.faint} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )}
          </React.Fragment>
        ))}
      </div>

      <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "0 0 16px" }}>Research directions</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 14 }}>
        {aiAreas.map((area) => (
          <div key={area} className="ap-card" style={{ padding: "18px 20px" }}>
            <p style={{ fontSize: 14.5, fontWeight: 600, margin: "0 0 8px", color: c.ink }}>{area}</p>
            <span style={{ fontSize: 11.5, fontWeight: 600, color: c.accentDark, background: c.accentTint, padding: "3px 9px", borderRadius: 999 }}>Research direction</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================================
   Page: Experience
   ========================================================= */
function ExperiencePage() {
  return (
    <section style={{ maxWidth: 1160, margin: "0 auto", padding: "56px 24px 20px" }}>
      <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Experience</p>
      <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 40px" }}>Professional experience</h2>

      <div style={{ display: "grid", gap: 20, marginBottom: 56 }}>
        {experience.map((e) => (
          <div key={e.role} className="ex-card">
            <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 6 }}>
              <h3 style={{ fontSize: 17, fontWeight: 700, margin: 0 }}>{e.role}</h3>
              <span style={{ fontSize: 13, color: c.faint }}>{e.period}</span>
            </div>
            <p style={{ fontSize: 14.5, color: c.accentDark, fontWeight: 600, margin: "0 0 18px" }}>{e.org}</p>
            <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 10 }}>
              {e.bullets.map((b) => (
                <li key={b} style={{ display: "flex", gap: 10, fontSize: 14, color: c.sub, lineHeight: 1.65 }}>
                  <Check /><span>{b}</span>
                </li>
              ))}
            </ul>
            {e.link && (
              <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", marginTop: 18 }}>
                <a href={e.link.href} target="_blank" rel="noreferrer" className="jn2-btn-secondary" style={{ fontSize: 13.5, padding: "9px 16px" }}>{e.link.label}</a>
                <span style={{ fontSize: 12, fontWeight: 600, color: c.accentDark, background: c.accentTint, padding: "5px 10px", borderRadius: 999 }}>~150 visitors</span>
              </div>
            )}
          </div>
        ))}
      </div>

      <p style={{ fontSize: 13, fontWeight: 600, color: c.faint, margin: "0 0 16px" }}>Healthcare workflow project</p>
      <div className="ex-card" style={{ marginBottom: 24, background: c.bgAlt }}>
        <h3 style={{ fontSize: 16, fontWeight: 700, margin: "0 0 4px" }}>HLA laboratory workflow documentation</h3>
        <p style={{ fontSize: 13, color: c.faint, margin: "0 0 18px" }}>On-site observation · Report preparation</p>
        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 8 }}>
          {["Conducted on-site observation of laboratory workflows and authored a structured observation report."].map(p => <li key={p} style={{ display: "flex", gap: 10, fontSize: 13.5, color: c.sub, lineHeight: 1.6 }}><Check /><span>{p}</span></li>)}
        </ul>
      </div>
      <p style={{ fontSize: 13, fontWeight: 600, color: c.faint, margin: "0 0 16px" }}>Academic project</p>
      <div className="ex-card" style={{ marginBottom: 64, background: c.bgAlt }}>
        <h3 style={{ fontSize: 16, fontWeight: 700, margin: "0 0 4px" }}>{secondaryProject.title}</h3>
        <p style={{ fontSize: 13, color: c.faint, margin: "0 0 18px" }}>{secondaryProject.meta}</p>
        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 8 }}>
          {secondaryProject.points.map((p) => (
            <li key={p} style={{ display: "flex", gap: 10, fontSize: 13.5, color: c.sub, lineHeight: 1.6 }}>
              <Check /><span>{p}</span>
            </li>
          ))}
        </ul>
      </div>

      <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Skills</p>
      <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 32px" }}>What I work with</h2>
      <div className="ex-two-col" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 64 }}>
        {skillGroups.map((g) => (
          <div key={g.title} className="ex-card">
            <h3 style={{ fontSize: 15, fontWeight: 700, margin: "0 0 16px" }}>{g.title}</h3>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {g.items.map((item) => <span key={item} className="ex-chip">{item}</span>)}
            </div>
          </div>
        ))}
      </div>

      <div className="ex-two-col" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
        <div className="ex-card">
          <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Education</p>
          <h3 style={{ fontSize: 17, fontWeight: 700, margin: "0 0 4px" }}>Bachelor of Science in Statistics</h3>
          <p style={{ fontSize: 14, color: c.sub, margin: "0 0 4px" }}>King Abdulaziz University, Jeddah, Saudi Arabia</p>
          <p style={{ fontSize: 13, color: c.faint, margin: "0 0 18px" }}>Graduated June 2026</p>
          <p style={{ fontSize: 12.5, fontWeight: 600, color: c.faint, margin: "0 0 10px" }}>Relevant coursework</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {coursework.map((item) => <span key={item} className="ex-chip" style={{ fontSize: 12.5 }}>{item}</span>)}
          </div>
        </div>

        <div className="ex-card">
          <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Certifications & training</p>
          <div style={{ display: "grid", gap: 16 }}>
            {certifications.map((cert) => (
              <div key={cert.name}>
                <p style={{ fontSize: 14, fontWeight: 600, color: c.ink, margin: "0 0 2px", lineHeight: 1.4 }}>{cert.name}</p>
                <p style={{ fontSize: 12.5, color: c.sub, margin: 0 }}>{cert.org} · {cert.meta}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   Page: Summary
   ========================================================= */
function SummaryPage() {
  return (
    <section style={{ maxWidth: 1160, margin: "0 auto", padding: "56px 24px 100px" }}>
      <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Summary</p>
      <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 14px" }}>One-page summary</h2>
      <p style={{ fontSize: 16, color: c.sub, lineHeight: 1.7, maxWidth: 600, margin: "0 0 32px" }}>
        This site is the full picture. For a quick reference, download a
        concise one-page summary of the research, experience, and skills above.
      </p>

      <div className="ex-card" style={{ maxWidth: 480, display: "flex", alignItems: "center", gap: 18 }}>
        <div aria-hidden="true" style={{ width: 44, height: 44, borderRadius: 10, background: c.accentTint, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <rect x="5" y="3" width="14" height="18" rx="2" stroke={c.accentDark} strokeWidth="1.6" />
            <path d="M8.5 8h7M8.5 12h7M8.5 16h4" stroke={c.accentDark} strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </div>
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: 14.5, fontWeight: 600, color: c.ink, margin: "0 0 2px" }}>Jory Sulemani — Summary</p>
          <p style={{ fontSize: 12.5, color: c.faint, margin: 0 }}>One page · PDF</p>
        </div>
        <a href={SUMMARY_FILE_URL} download className="jn2-btn-primary" style={{ fontSize: 13.5, padding: "9px 16px", flexShrink: 0 }}>Download</a>
      </div>
    </section>
  );
}

/* =========================================================
   Page: Contact
   ========================================================= */
function ContactPage() {
  const [contactForm, setContactForm] = useState({ name: "", email: "", message: "" });
  return (
    <section style={{ maxWidth: 1160, margin: "0 auto", padding: "56px 24px 100px" }}>
      <p style={{ fontSize: 13, fontWeight: 600, color: c.accentDark, margin: "0 0 12px" }}>Contact</p>
      <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: "-0.01em", margin: "0 0 16px" }}>Get in touch</h2>
      <p style={{ fontSize: 16, color: c.sub, lineHeight: 1.7, maxWidth: 560, margin: "0 0 32px" }}>
        For research collaboration, statistical analysis, or employment opportunities, get in touch by email or LinkedIn.
      </p>

      <div className="ex-two-col" style={{ display: "grid", gridTemplateColumns: "1.1fr 0.9fr", gap: 24 }}>
        <form
          className="ex-card"
          onSubmit={(e) => {
            e.preventDefault();
            const subject = encodeURIComponent(`Portfolio inquiry from ${contactForm.name || "a visitor"}`);
            const body = encodeURIComponent(`${contactForm.message}\n\n—\n${contactForm.name}\n${contactForm.email}`);
            window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
          }}
        >
          <div style={{ display: "grid", gap: 16, marginBottom: 20 }}>
            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: c.sub }}>Name</span>
              <input required value={contactForm.name} onChange={(e) => setContactForm((f) => ({ ...f, name: e.target.value }))} style={{ border: `1px solid ${c.border}`, borderRadius: 8, padding: "10px 12px", fontSize: 14, background: c.bg, color: c.ink, fontFamily: "inherit" }} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: c.sub }}>Email</span>
              <input required type="email" value={contactForm.email} onChange={(e) => setContactForm((f) => ({ ...f, email: e.target.value }))} style={{ border: `1px solid ${c.border}`, borderRadius: 8, padding: "10px 12px", fontSize: 14, background: c.bg, color: c.ink, fontFamily: "inherit" }} />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: c.sub }}>Message</span>
              <textarea required rows={4} value={contactForm.message} onChange={(e) => setContactForm((f) => ({ ...f, message: e.target.value }))} style={{ border: `1px solid ${c.border}`, borderRadius: 8, padding: "10px 12px", fontSize: 14, background: c.bg, color: c.ink, fontFamily: "inherit", resize: "vertical" }} />
            </label>
          </div>
          <button type="submit" className="jn2-btn-primary" style={{ border: "none" }}>Compose email</button>
          <p style={{ fontSize: 12, color: c.faint, margin: "12px 0 0" }}>Opens your email app, addressed to Jory.</p>
        </form>

        <div className="ex-card" style={{ background: c.bgAlt, alignSelf: "start" }}>
          <p style={{ fontSize: 13, fontWeight: 700, margin: "0 0 10px" }}>Email & professional profiles</p>
          <a href={`mailto:${CONTACT_EMAIL}`} style={{ color: c.accentDark, fontSize: 14, overflowWrap: "anywhere", display: "block", marginBottom: 18 }}>{CONTACT_EMAIL}</a>
          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
            {SOCIAL_LINKS.linkedin && (
              <a href={SOCIAL_LINKS.linkedin} target="_blank" rel="noreferrer" className="jn2-btn-secondary" style={{ fontSize: 13.5, padding: "9px 16px", textAlign: "center" }}>LinkedIn</a>
            )}
            <a href={SOCIAL_LINKS.github} target="_blank" rel="noreferrer" className="jn2-btn-secondary" style={{ fontSize: 13.5, padding: "9px 16px", textAlign: "center" }}>Coffee Statistics on GitHub</a>
          </div>
          <p style={{ fontSize: 12.5, color: c.faint, lineHeight: 1.6, margin: 0 }}>
            Coffee Statistics is an educational statistics website independently
            developed and published, reaching approximately 150 visitors.
          </p>
        </div>
      </div>
    </section>
  );
}

/* =========================================================
   Layout — nav, theme, progress bar, footer, back-to-top
   (shared chrome around every page)
   ========================================================= */
export default function Portfolio() {
  const [path, navigate] = useHashRoute();
  const segments = path.split("/").filter(Boolean); // e.g. ["research","results"]
  const top = segments[0] || "";
  const sub = segments[1];

  const [menuOpen, setMenuOpen] = useState(false);
  const [theme, setTheme] = useState("light");
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    applyTheme(next);
    setTheme(next);
  };

  // New page → jump to the top, like a real page navigation.
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
    setMenuOpen(false);
  }, [top]);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const scrolled = h.scrollTop;
      const max = h.scrollHeight - h.clientHeight;
      setScrollProgress(max > 0 ? (scrolled / max) * 100 : 0);
      setShowBackToTop(scrolled > 600);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [top]);

  let PageContent;
  if (top === "research") PageContent = <ResearchPage subPath={sub} navigate={navigate} />;
  else if (top === "approach") PageContent = <ApproachPage />;
  else if (top === "healthcare-ai") PageContent = <HealthcareAIPage />;
  else if (top === "experience") PageContent = <ExperiencePage />;
  else if (top === "summary") PageContent = <SummaryPage />;
  else if (top === "contact") PageContent = <ContactPage />;
  else PageContent = <HomePage navigate={navigate} />;

  return (
    <div style={{ background: c.bg, color: c.ink, fontFamily: "'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif", minHeight: "100vh" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

        html { scroll-behavior: smooth; }

        .page-fade { animation: pageFadeIn 0.32s ease; }
        @keyframes pageFadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        @media (prefers-reduced-motion: reduce) { .page-fade, .jn2-fade, .rs-panel, .ap-acc-body { animation: none !important; transition: none !important; transform: none !important; opacity: 1 !important; } }

        .jn2-fade { opacity: 0; transform: translateY(14px); transition: opacity 0.55s ease, transform 0.55s ease; }
        .jn2-fade.jn2-in { opacity: 1; transform: translateY(0); }

        .jn2-link { color: ${c.sub}; text-decoration: none; font-size: 14.5px; font-weight: 500; background: none; border: none; cursor: pointer; font-family: inherit; padding-bottom: 3px; border-bottom: 2px solid transparent; transition: color 0.15s ease, border-color 0.15s ease; }
        .jn2-link:hover, .jn2-link:focus-visible { color: ${c.ink}; }
        .jn2-link.active { color: ${c.ink}; font-weight: 600; border-bottom-color: ${c.accent}; }
        .jn2-link:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 3px; border-radius: 3px; }

        .jn2-btn-primary { background: ${c.accent}; color: #fff; border: 1px solid ${c.accent}; border-radius: 8px; padding: 12px 22px; font-size: 15px; font-weight: 600; text-decoration: none; display: inline-block; transition: background 0.15s ease, transform 0.1s ease; cursor: pointer; font-family: inherit; }
        .jn2-btn-primary:hover { background: ${c.accentDark}; }
        .jn2-btn-primary:active { transform: scale(0.98); }
        .jn2-btn-primary:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 3px; }

        .jn2-btn-secondary { background: transparent; color: ${c.ink}; border: 1px solid ${c.border}; border-radius: 8px; padding: 12px 22px; font-size: 15px; font-weight: 600; text-decoration: none; display: inline-block; transition: border-color 0.15s ease, background 0.15s ease; cursor: pointer; font-family: inherit; }
        .jn2-btn-secondary:hover { border-color: ${c.faint}; background: ${c.bgAlt}; }
        .jn2-btn-secondary:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 3px; }

        .jn2-card { border: 1px solid ${c.border}; border-radius: 14px; background: ${c.card}; transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.2s ease; }
        .jn2-card:hover { border-color: ${c.faint}; box-shadow: 0 4px 14px rgba(16, 24, 40, 0.06); }
        .teaser-card:hover span { text-decoration: underline; }

        .jn2-burger { display: none; background: none; border: 1px solid ${c.border}; border-radius: 8px; width: 38px; height: 38px; align-items: center; justify-content: center; cursor: pointer; }
        @media (max-width: 900px) { .jn2-nav-links { display: none; } .jn2-nav-cta { display: none; } .jn2-burger { display: flex; } }
        @media (max-width: 900px) { .jn2-hero-grid { grid-template-columns: 1fr !important; } .jn2-panel { margin-top: 40px; } }
        @media (max-width: 640px) { .jn2-hero-title { font-size: 40px !important; } .jn2-snap-grid { grid-template-columns: 1fr 1fr !important; } }
        @media (max-width: 460px) { .jn2-snap-grid { grid-template-columns: 1fr !important; } }

        .rs-tab { background: transparent; border: 1px solid ${c.border}; border-radius: 999px; padding: 9px 16px; font-size: 13.5px; font-weight: 600; color: ${c.sub}; cursor: pointer; white-space: nowrap; transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease; font-family: inherit; }
        .rs-tab:hover { border-color: ${c.faint}; color: ${c.ink}; }
        .rs-tab.on { background: ${c.accent}; border-color: ${c.accent}; color: #fff; }
        .rs-tab:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 2px; }
        .rs-card { border: 1px solid ${c.border}; border-radius: 14px; background: ${c.card}; }
        .rs-method { border: 1px solid ${c.border}; border-radius: 10px; padding: 10px 14px; font-size: 13px; font-weight: 600; color: ${c.sub}; background: ${c.card}; cursor: pointer; text-align: left; transition: border-color 0.15s ease, background 0.15s ease, color 0.15s ease; font-family: inherit; }
        .rs-method:hover { border-color: ${c.faint}; }
        .rs-method.on { background: ${c.accentTint}; border-color: ${c.accent}; color: ${c.accentDark}; }
        .rs-method:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 2px; }
        .rs-panel { animation: apFade 0.3s ease; }
        @keyframes apFade { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        .rs-limrow { width: 100%; text-align: left; background: none; border: none; border-top: 1px solid ${c.border}; padding: 16px 0; cursor: pointer; display: flex; justify-content: space-between; align-items: center; gap: 12px; font-family: inherit; }
        .rs-limrow:first-child { border-top: none; }
        .rs-limrow:focus-visible { outline: 2px solid ${c.accent}; outline-offset: 2px; }
        @media (max-width: 760px) { .rs-two-col { grid-template-columns: 1fr !important; } .rs-stat-row { grid-template-columns: 1fr 1fr !important; } }

        .ap-acc-item { border: 1px solid ${c.border}; border-radius: 12px; overflow: hidden; background: ${c.card}; }
        .ap-acc-head { width: 100%; text-align: left; background: none; border: none; padding: 16px 18px; cursor: pointer; display: flex; align-items: center; gap: 12px; font-family: inherit; transition: background 0.15s ease; }
        .ap-acc-head:hover { background: ${c.bgAlt}; }
        .ap-acc-head.on { background: ${c.accentTint}; }
        .ap-acc-head:focus-visible { outline: 2px solid ${c.accent}; outline-offset: -2px; }
        .ap-acc-head.on .ap-num { background: ${c.accent}; color: #fff; }
        .ap-acc-body { padding: 4px 18px 20px 50px; animation: apFade 0.25s ease; }
        .ap-num { width: 26px; height: 26px; border-radius: 50%; background: ${c.bgAlt}; color: ${c.sub}; font-size: 12.5px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .ap-bridge { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .ap-node { border: 1px solid ${c.border}; border-radius: 10px; padding: 12px 16px; font-size: 13.5px; font-weight: 600; background: ${c.card}; white-space: nowrap; color: ${c.ink}; }
        .ap-node.last { background: ${c.accent}; color: #fff; border-color: ${c.accent}; }
        .ap-card { border: 1px solid ${c.border}; border-radius: 14px; background: ${c.card}; }

        .ex-card { border: 1px solid ${c.border}; border-radius: 14px; background: ${c.card}; padding: 28px; }
        .ex-chip { border: 1px solid ${c.border}; border-radius: 8px; padding: 7px 12px; font-size: 13px; font-weight: 500; color: ${c.sub}; background: ${c.card}; display: inline-block; }
        @media (max-width: 760px) { .ex-two-col { grid-template-columns: 1fr !important; } }
      `}</style>

      {/* ===================== Nav ===================== */}
      <header style={{ position: "sticky", top: 0, zIndex: 20, background: c.navBg, backdropFilter: "blur(8px)", borderBottom: `1px solid ${c.border}` }}>
        <div style={{ maxWidth: 1160, margin: "0 auto", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <a href="#/" onClick={(e) => { e.preventDefault(); navigate("/"); }} style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none", color: c.ink }}>
            <span aria-hidden="true" style={{ width: 30, height: 30, borderRadius: 8, background: c.accent, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700 }}>JS</span>
            <span style={{ fontSize: 15.5, fontWeight: 600 }}>Jory Sulemani</span>
          </a>

          <nav className="jn2-nav-links" aria-label="Primary" style={{ display: "flex", gap: 28, alignItems: "center" }}>
            {ROUTES.map((r) => (
              <a key={r.path} href={`#${r.path}`} onClick={(e) => { e.preventDefault(); navigate(r.path); }} className={`jn2-link ${path.startsWith(r.path) ? "active" : ""}`}>{r.label}</a>
            ))}
            <button
              onClick={toggleTheme}
              aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
              style={{ background: "none", border: `1px solid ${c.border}`, borderRadius: 8, width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: c.ink }}
            >
              {theme === "dark" ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="4.5" stroke="currentColor" strokeWidth="1.7" /><path d="M12 2v2.2M12 19.8V22M4.2 4.2l1.6 1.6M18.2 18.2l1.6 1.6M2 12h2.2M19.8 12H22M4.2 19.8l1.6-1.6M18.2 5.8l1.6-1.6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" /></svg>
              )}
            </button>
          </nav>

          <a href="#/summary" onClick={(e) => { e.preventDefault(); navigate("/summary"); }} className="jn2-btn-primary jn2-nav-cta" style={{ padding: "9px 18px", fontSize: 14 }}>Download summary</a>

          <button className="jn2-burger" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen((v) => !v)}>
            <svg width="16" height="12" viewBox="0 0 16 12" fill="none"><path d="M0 1h16M0 6h16M0 11h16" stroke={c.ink} strokeWidth="1.5" /></svg>
          </button>
        </div>

        {menuOpen && (
          <nav aria-label="Mobile" style={{ borderTop: `1px solid ${c.border}`, padding: "14px 24px 20px", display: "flex", flexDirection: "column", gap: 14 }}>
            {ROUTES.map((r) => (
              <a key={r.path} href={`#${r.path}`} onClick={(e) => { e.preventDefault(); navigate(r.path); setMenuOpen(false); }} className={`jn2-link ${path.startsWith(r.path) ? "active" : ""}`} style={{ fontSize: 15 }}>{r.label}</a>
            ))}
            <a href="#/summary" onClick={(e) => { e.preventDefault(); navigate("/summary"); setMenuOpen(false); }} className="jn2-btn-primary" style={{ textAlign: "center", marginTop: 6 }}>Download summary</a>
            <button
              onClick={() => { toggleTheme(); setMenuOpen(false); }}
              style={{ display: "flex", alignItems: "center", gap: 8, background: "none", border: `1px solid ${c.border}`, borderRadius: 8, padding: "9px 14px", fontSize: 14, color: c.ink, cursor: "pointer", fontFamily: "inherit", width: "fit-content" }}
            >
              {theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            </button>
          </nav>
        )}
      </header>

      <div aria-hidden="true" style={{ position: "sticky", top: 0, height: 2, background: c.border, zIndex: 21 }}>
        <div style={{ height: "100%", width: `${scrollProgress}%`, background: c.accent, transition: "width 0.1s linear" }} />
      </div>

      <main key={top} className="page-fade">
        {PageContent}
      </main>

      {/* ===================== Footer ===================== */}
      <footer style={{ borderTop: `1px solid ${c.border}` }}>
        <div style={{ maxWidth: 1160, margin: "0 auto", padding: "36px 24px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 20 }}>
          <div>
            <p style={{ fontSize: 14.5, fontWeight: 700, margin: "0 0 4px" }}>Jory Sulemani</p>
            <p style={{ fontSize: 13, color: c.sub, margin: 0 }}>Medical statistics · Biomedical data · Healthcare AI</p>
          </div>
          <nav aria-label="Footer" style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
            <a href="#/research" onClick={(e) => { e.preventDefault(); navigate("/research"); }} className="jn2-link">Research</a>
            <a href="#/summary" onClick={(e) => { e.preventDefault(); navigate("/summary"); }} className="jn2-link">Summary</a>
            <a href={SOCIAL_LINKS.github} target="_blank" rel="noreferrer" className="jn2-link">GitHub</a>
            {SOCIAL_LINKS.linkedin && <a href={SOCIAL_LINKS.linkedin} target="_blank" rel="noreferrer" className="jn2-link">LinkedIn</a>}
            <a href="#/contact" onClick={(e) => { e.preventDefault(); navigate("/contact"); }} className="jn2-link">Contact</a>
          </nav>
        </div>
      </footer>

      {showBackToTop && (
        <a
          href="#/"
          onClick={(e) => { e.preventDefault(); if (top === "") { window.scrollTo({ top: 0, behavior: "smooth" }); } else { navigate("/"); } }}
          aria-label="Back to top"
          style={{ position: "fixed", bottom: 24, right: 24, width: 44, height: 44, borderRadius: "50%", background: c.accent, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 6px 18px rgba(14,124,134,0.35)", zIndex: 30, textDecoration: "none" }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path d="M8 13V3M3.5 7.5 8 3l4.5 4.5" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </a>
      )}
    </div>
  );
}
